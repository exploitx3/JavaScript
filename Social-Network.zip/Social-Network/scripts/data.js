var app = app || {};
app.data = (function () {

    var credentials = (function () {

        function getBaseAppUrl() {
            return 'https://baas.kinvey.com/appdata/kid_Wy0u36CI1Z/';
        }

        function getBaseUserUrl() {
            return 'https://baas.kinvey.com/user/kid_Wy0u36CI1Z/';
        }

        function getSessionToken() {
            return sessionStorage.getItem('SessionAuthToken');
        }

        function setSessionToken(token) {
            if (!sessionStorage.getItem('SessionAuthToken')) {
                sessionStorage.setItem('SessionAuthToken', token);
            }
        }

        function getUserId() {
            return sessionStorage.getItem('UserId');
        }

        function setUserId(usrId) {
            if (!sessionStorage.getItem('UserId')) {
                sessionStorage.setItem('UserId', usrId);
            }
        }

        function getUsername() {
            return sessionStorage.getItem('Username');
        }

        function setUsername(username) {
            if (!sessionStorage.getItem('Username')) {
                sessionStorage.setItem('Username', username);
            }
        }

        function clearStorage() {
            sessionStorage.removeItem('SessionAuthToken');
            sessionStorage.removeItem('UserId');
            sessionStorage.removeItem('Username');
        }

        return {
            getBaseAppUrl: getBaseAppUrl,
            getBaseUserUrl: getBaseUserUrl,
            getSessionToken: getSessionToken,
            setSessionToken: setSessionToken,
            getUserId: getUserId,
            setUserId: setUserId,
            getUsername: getUsername,
            setUsername: setUsername,
            clearStorage: clearStorage
        };
    })();

    var users = function (ajaxRequester) {

        function login(username, password) {
            var defer = Q.defer();
            var data = {
                username: username,
                password: password
            };

            var headers = {
                'Content-Type': 'application/json',
                'Authorization': 'Basic a2lkX1d5MHUzNkNJMVo6MWU0OTg1ZjU0ZjkxNGFjN2FkNGJiODMxYjhjZWE4ZDg='
            };

            ajaxRequester.makePostRequest(credentials.getBaseUserUrl() + 'login', headers, data)
                .then(function (data) {


                    credentials.clearStorage();
                    credentials.setSessionToken(data._kmd.authtoken);
                    credentials.setUserId(data._id);
                    credentials.setUsername(data.username);
                    defer.resolve(data);

                }, function (error) {
                    defer.reject(error);
                });


            return defer.promise;
        }

        function register(username, password, name, aboutInfo, gender, picture) {
            var defer = Q.defer();
            var data = {
                username: username,
                password: password,
                name: name,
                about: aboutInfo,
                gender: gender,
                picture: picture
            };

            var headers = {
                'Content-Type': 'application/json',
                'Authorization': 'Basic a2lkX1d5MHUzNkNJMVo6MWU0OTg1ZjU0ZjkxNGFjN2FkNGJiODMxYjhjZWE4ZDg='
            };

            ajaxRequester.makePostRequest(credentials.getBaseUserUrl(), headers, data)
                .then(function (data) {
                    credentials.clearStorage();
                    credentials.setSessionToken(data._kmd.authtoken);
                    credentials.setUserId(data._id);
                    credentials.setUsername(data.username);

                    defer.resolve(data);
                });


            return defer.promise;
        }

        function editProfile(data) {
            var data = data || {};
            var defer = Q.defer();
            var headers = {
                'Content-Type': 'application/json',
                'Authorization': 'Kinvey ' + credentials.getSessionToken()
            };

            ajaxRequester.makePutRequest(credentials.getBaseUserUrl() + credentials.getUserId(), headers, data)
                .then(function (info) {
                    defer.resolve(info);
                })
                .done();
            //TODO: I'm not sure if the info in the database will change completeley makeing the session useless
            return defer.promise;
        }

        function deleteProfile() {
            var defer = Q.defer();
            var headers = {
                'Authorization': 'Kinvey ' + credentials.getSessionToken()
            };

            ajaxRequester.makeDeleteRequest(credentials.getBaseUserUrl() + credentials.getUserId()+'/?hard=true', headers)
                .then(function (info) {
                    defer.resolve(info);
                })
                .done();
            return defer.promise;
        }

        function getById(id) {
            var defer = Q.defer();
            var headers = {
                'Authorization': 'Kinvey ' + credentials.getSessionToken()
            };

            var responseData = ajaxRequester.makeGetRequest(credentials.getBaseUserUrl() + id, headers)
                .then(function (data) {
                    defer.resolve(data);
                }, function (error) {
                    console.error(error);
                });

            return defer.promise;
        }

        function validateLoggedIn() {
            return sessionStorage.hasOwnProperty('SessionAuthToken');
        }

        function getUserData() {
            var defer = Q.defer();
            var headers = {
                'Authorization': 'Kinvey ' + credentials.getSessionToken()
            };

            ajaxRequester.makeGetRequest(credentials.getBaseUserUrl() + credentials.getUserId(), headers)
                .then(function (data) {
                    defer.resolve(data);
                }, function (error) {
                    console.error(error);
                });

            return defer.promise;
        }

        function logout() {
            var defer = Q.defer();
            var headers = {
                'Authorization': 'Kinvey ' + credentials.getSessionToken()
            };

            ajaxRequester.makePostRequest(credentials.getBaseUserUrl() + '_logout', headers)
                .then(function (data) {
                    defer.resolve(data);
                }, function (error) {
                    console.error(error);
                });

            credentials.clearStorage();

            return defer.promise;
        }

        return {
            deleteProfile: deleteProfile,
            register: register,
            editProfile: editProfile,
            getById: getById,
            getUserData: getUserData,
            login: login,
            logout: logout,
            validateLoggedIn: validateLoggedIn
        };
    };

    var posts = function (ajaxRequester) {

        function getAllPosts() {
            var defer = Q.defer();
            var headers = {
                'Authorization': 'Kinvey ' + credentials.getSessionToken()
            };

            var responseData = ajaxRequester.makeGetRequest(credentials.getBaseAppUrl() + 'Posts/?resolve=createdBy', headers)
                .then(function (data) {
                    defer.resolve(data);
                    return data;
                }, function (error) {
                    console.error(error);
                });

            return defer.promise;
        }

        function getPostById(id) {
            var defer = Q.defer();
            var headers = {
                'Authorization': 'Kinvey ' + credentials.getSessionToken()
            };

            ajaxRequester.makeGetRequest(credentials.getBaseAppUrl() + 'Posts/' + id, headers)
                .then(function (data) {
                    defer.resolve(data);
                    return data;
                }, function (error) {
                    console.error(error);
                });

            return defer.promise;
        }

        function addNewPost(newPostData) {
            var defer = Q.defer();
            var newPostData = newPostData || {};
            var headers = {
                'Authorization': 'Kinvey ' + credentials.getSessionToken(),
                'Content-Type': 'application/json'
            };

            ajaxRequester.makePostRequest(credentials.getBaseAppUrl() + 'Posts/', headers, newPostData)
                .then(function (data) {
                    defer.resolve(data);
                }, function (error) {
                    console.error(error);
                });

            return defer.promise;
        }

        return {
            addNewPost: addNewPost,
            getPostById: getPostById,
            getAllPosts: getAllPosts
        }
    };

    return {
        get: function (requester) {
            return {
                users: users(requester),
                posts: posts(requester)
            }
        }
    };
})();