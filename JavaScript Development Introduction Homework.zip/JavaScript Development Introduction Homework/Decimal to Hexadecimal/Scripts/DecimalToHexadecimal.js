/**
 * Created by Leet on 1/9/2016.
 */
var decNumber = prompt("enter amount");
alert(parseInt(decNumber).toString(16).toLocaleUpperCase());
