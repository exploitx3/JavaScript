/**
 * Created by Leet on 1/9/2016.
 */
var date = new Date();
console.log(date);